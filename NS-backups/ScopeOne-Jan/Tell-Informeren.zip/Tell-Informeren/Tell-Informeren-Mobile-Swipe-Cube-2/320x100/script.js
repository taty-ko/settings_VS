//////////////////////
// LEMONPI CALLBACK //
//////////////////////

// Set values from LemonPI Manage-r

let video;
var nextClick = false;

lemonpi.subscribe(function callback(content) {
  // PLACEHOLDER SETTINGS
  // All text
  console.log(content);
  $(".text1").html(content.text1.value);
  $(".textFrame2").html(content.textFrame2.value);
  $(".textFrame3").html(content.textFrame3.value);
  $(".stationText").html(content.stationText.value);
  $(".stationTextBottom").html(content.stationTextBottom.value);
  $(".trainText").html(content.trainText.value);  
  $(".btnText").html(content.btnText.value);

  if (content.blueText && content.blueText.value === true) {
    $('.stationText').css('color', '#003082');
    $('.stationTextBottom').css('color', '#003082');
    }

  $(".gifFirst").css("background-image", "url(" + content.gifFirst.value + ")");
  $(".gifFrame2").css("background-image", "url(" + content.gifFrame2.value + ")");
  $(".gifFrame3").css("background-image", "url(" + content.gifFrame3.value + ")");

  video = $('.videoSecond').append('<video muted src="' + content.stationVideo.value + '"></video>').find('video')[0];

  // CLICKOUT SETTINGS
  // Element for clickout
  var selector = document.getElementById("click");

  // On click function
  selector.onclick = function () {
    return window.dispatchEvent(
      // Call lemonpi function
      new CustomEvent("lemonpi.interaction/click", {
        detail: {
          // Current placeholder name of url
          placeholder: "clickUrl",
          query: {},
        },
      })
    );
  };
});

// Debug:
// video = $('.videoSecond').append('<video muted style="width:450px;" src="./video.mp4"></video>').find('video')[0];

window.swiper = new Swiper('.swiper', {
  autoplay: { 
    stopOnLastSlide: true,
    delay: 4000 
  },
  grabCursor: true,

  effect: 'cube',
  loop: false,
  speed: 800,

  navigation: {
    nextEl: '#navigation-next',
    prevEl: '#navigation-prev',
  },

  cubeEffect: {
    slideShadows: false, // true,
    // shadowScale: 0.34,
    // shadowOffset: 20,
    shadow: false // true,
  },

  on: {
    slideChange: function (event) {
      event.touches.diff > 0 && setTimeout(function () {
        if (nextClick) return setTimeout(function () {
          nextClick = false;
        });

        var duplicate = document.querySelector('.swiper-slide-prev.swiper-slide-duplicate-next');
        duplicate && duplicate.classList.remove('swiper-slide-duplicate-next');
        duplicate && duplicate.classList.remove('swiper-slide-prev');
      });

      if (video) {
        video.currentTime = 0;
        video.play();
      }
    }
  }
});

document.getElementById('navigation-prev').addEventListener('click', function () {
  setTimeout(function () {
    var duplicate = document.querySelector('.swiper-slide-prev.swiper-slide-duplicate-next');
    duplicate && duplicate.classList.remove('swiper-slide-duplicate-next');
    duplicate && duplicate.classList.remove('swiper-slide-prev');
  });
});

document.getElementById('navigation-next').addEventListener('click', function () {
  nextClick = true;
});
