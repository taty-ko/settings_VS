"use strict";

const firstSlotForText = document.querySelector('.firstSlot');
const secondSlotForText = document.querySelector('.secondSlot');
const thirdSlotForText = document.querySelector('.thirdSlot');

//copy for slot
const firstSlot = [
    'Elke maandag-ochtend',
    "Af en toe's nachts",
    'Om de week',
    'Elke woensdagavond',
    'Tijdens de feestdagen',
    // 'Tijdens het spitsuur',
    "Af en toe's nachts",
    'Echt elke dag weer ',
    // 'Vanaf nu even niet meer',
    'Om de week',
    'Elke zaterdagnacht'
]
const secondSlot = [
    'met je opa',
    'met de bingoclub',
    'met je dochter',
    'met je ex',
    'met je BFF',
    "met je collega's",
    'met je vriendinnen',
    'met een totaal onbekende',
    'lekker helemaal alleen',
]
const thirdSlot = [
    'naar de Jumphal',
    'abseilen van de Euromast?',
    'een potje strandjutten?',
    'spelen in de ballenbak?',
    'suppen in de grachten?',
    'dansen in de club?',
    'verdwalen op de fiets?',
    'naar de sauna?',
    'scrummen op de hei?'
]

//add div with copy
function addFirstSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
        let divVox = document.createElement('div')
        divVox.innerHTML = i;
        divVox.classList.add('vox')
        firstSlotForText.append(divVox)
        console.log(divVox);
    })
}

function addSecondSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
        let divVox = document.createElement('div')
        divVox.innerHTML = i;
        divVox.classList.add('vox')
        secondSlotForText.append(divVox)
        console.log(divVox);
    })
}

function addThirdSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
        let divVox = document.createElement('div')
        divVox.innerHTML = i;
        divVox.classList.add('vox')
        thirdSlotForText.append(divVox)
        console.log(divVox);
    })
}


//shuffle arr copy
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1)); // случайный индекс от 0 до i

        // поменять элементы местами
        // мы используем для этого синтаксис "деструктурирующее присваивание"
        // подробнее о нём - в следующих главах
        // то же самое можно записать как:
        // let t = array[i]; array[i] = array[j]; array[j] = t
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array
}

addFirstSlot(firstSlot)
addSecondSlot(secondSlot)
addThirdSlot(thirdSlot)