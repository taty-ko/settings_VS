//////////////////////
// LEMONPI CALLBACK //
//////////////////////

// Set values from LemonPI Manage-r

var videoContent = '';
var hasClicked = false;
var lever = document.getElementById('lever');

function onLeverClick (event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }

  if (hasClicked) return;
  hasClicked = !hasClicked;

  /* setTimeout(function () {
    $('.video').append('<video muted autoplay="autoplay" src="' + videoContent + '"></video>');
  }, 6800);
 */
  var container = document.getElementById('creative_container');
  var fortuneBlock = document.getElementsByClassName('fortuneBlock')[0];

  fortuneBlock.style.animationPlayState = 'running';
  container.classList.remove('idle');
  lever.classList.add('clicked');

  var text1 = document.querySelector('.frame-1 .text1');
  text1.style.animation = 'unset';

  setTimeout(function () {
    text1.style.transform = 'translate(0, 10px)';
    text1.style.opacity = '0';
  }, 4000);

  document.querySelectorAll('.firstFrameAnimation').forEach(function (element) {
    element.style.animationPlayState = 'running';
  });

  document.querySelectorAll('.box').forEach(function (box) {
    box.style.animationPlayState = 'running';
  });
}

lemonpi.subscribe(function callback(content) {
  // PLACEHOLDER SETTINGS
  // All text
  console.log(content);
  $(".text1").html(content.text1.value);
  $(".text2").html(content.text2.value);
  $(".text3").html(content.text3.value);
  $(".text4").html(content.text4.value);
  $(".text7").html(content.text7.value);
  $(".text8").html(content.text8.value);
  $(".text9").html(content.text9.value);


  // All images
  creative_container
  $(".fortune2").css("background-image", "url(" + content.fortune2.value + ")");
  $(".fortune").css("background-image", "url(" + content.fortune.value + ")");
  $(".lever").css("background-image", "url(" + content.lever.value + ")");
  $(".cloud").css("background-image", "url(" + content.cloud.value + ")");
  $(".train").css("background-image", "url(" + content.train.value + ")");
  $(".switch").css("background-image", "url(" + content.switch.value + ")");
  $(".aan").css("background-image", "url(" + content.aan.value + ")");
  $(".bol").css("background-image", "url(" + content.bol.value + ")");
  $(".logo").css("background-image", "url(" + content.logo.value + ")");
  $(".gifFirst").css("background-image", "url(" + content.gifFirst.value + ")");

/*   videoContent = content.video.value; */

  // setTimeout(function () {
  //   $('.video').append('<video muted autoplay="autoplay" src="' + content.video.value + '"></video>');
  // }, 6800);

  // CLICKOUT SETTINGS
  // Element for clickout
  var selector = document.getElementById("click");

  // On click function
  selector.onclick = function () {
    return window.dispatchEvent(
      // Call lemonpi function
      new CustomEvent("lemonpi.interaction/click", {
        detail: {
          // Current placeholder name of url
          placeholder: "clickUrl",
          query: {},
        },
      })
    );
  };
});

lever.addEventListener('click', onLeverClick);

setTimeout(function () {
  if (hasClicked === false) {
    onLeverClick();
  }
}, 5000);

function slotCopy() {
  const firstSlotForText = document.querySelector('.first');
  const secondSlotForText = document.querySelector('.second');
  const thirdSlotForText = document.querySelector('.third');

  //copy for slot
  const firstSlot = [
    'Elke maandag-ochtend',
    "Af en toe's nachts",
    'Om de week',
    'Elke woensdagavond',
    'Tijdens de feestdagen',
    // 'Tijdens het spitsuur',
    "Af en toe's nachts",
    'Echt elke dag weer ',
    // 'Vanaf nu even niet meer',
    'Om de week',
    'Elke zaterdagnacht'
  ]
  const secondSlot = [
    'met je opa',
    'met de bingoclub',
    'met je dochter',
    'met je ex',
    'met je BFF',
    "met je collega's",
    'met je vriendinnen',
    'met een totaal onbekende',
    'lekker helemaal alleen',
  ]
  const thirdSlot = [
    'naar de Jumphal',
    'abseilen van de Euromast?',
    'een potje strandjutten?',
    'spelen in de ballenbak?',
    'suppen in de grachten?',
    'dansen in de club?',
    'verdwalen op de fiets?',
    'naar de sauna?',
    'scrummen op de hei?'
  ]

  //add div with copy
  function addFirstSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
      let divVox = document.createElement('p')
      divVox.innerHTML = i;
      divVox.classList.add('box')
      firstSlotForText.append(divVox)
      console.log(divVox);
    })
  }

  function addSecondSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
      let divVox = document.createElement('p')
      divVox.innerHTML = i;
      divVox.classList.add('box')
      secondSlotForText.append(divVox)
      console.log(divVox);
    })
  }

  function addThirdSlot(arr) {
    let copy = shuffle(arr)
    copy.forEach((i) => {
      let divVox = document.createElement('p')
      divVox.innerHTML = i;
      divVox.classList.add('box')
      thirdSlotForText.append(divVox)
      console.log(divVox);
    })
  }


  //shuffle arr copy
  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1)); // случайный индекс от 0 до i

      // поменять элементы местами
      // мы используем для этого синтаксис "деструктурирующее присваивание"
      // подробнее о нём - в следующих главах
      // то же самое можно записать как:
      // let t = array[i]; array[i] = array[j]; array[j] = t
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array
  }

  addFirstSlot(firstSlot)
  addSecondSlot(secondSlot)
  addThirdSlot(thirdSlot)
}

slotCopy()