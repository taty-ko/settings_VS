//////////////////////
// LEMONPI CALLBACK //
//////////////////////
// Set values from LemonPI Manage-r
lemonpi.subscribe(function callback(content) {
  // PLACEHOLDER SETTINGS
  // All text
  console.log(content);
  $(".ad-text-line-1").html(content.adTextLine1.value);
  $(".ad-text-line-2").html(content.adTextLine2.value);
  $(".btn-text").html(content.btnText.value);
  const priceNumber = +content.price.value;
  const priceString = parseInt(priceNumber) === priceNumber ? `${priceNumber}` : priceNumber.toFixed(2);
  const price = $(".price").html(priceString);
  if (priceString.length == 1) {
    price.css({ fontSize: "60px" });
  } else if (priceString.length == 4) {
    price.css({ fontSize: "36px" });
  } else if (priceString.length == 5) {
    price.css({ fontSize: "30px" });
  } else if (priceString.length == 6) {
    price.css({ fontSize: "24px" });
  }
  // All images
  creative_container
  $(".cta-field").css("background-image", "url(" + content.ctaField.value + ")");
  $(".cta-text-switcher").css("background-image", "url(" + content.ctaTextSwitcher.value + ")");
  $(".cta-switcher").css("background-image", "url(" + content.ctaSwitcher.value + ")");
  $(".logo").css("background-image", "url(" + content.logo.value + ")");
  $(".pancake").css("background-image", "url(" + content.pancake.value + ")");
  // CLICKOUT SETTINGS
  // Element for clickout
  var selector = document.getElementById("click");
  // On click function
  selector.onclick = function () {
    return window.dispatchEvent(
      // Call lemonpi function
      new CustomEvent("lemonpi.interaction/click", {
        detail: {
          // Current placeholder name of url
          placeholder: "clickUrl",
          query: {},
        },
      })
    );
  };
});
